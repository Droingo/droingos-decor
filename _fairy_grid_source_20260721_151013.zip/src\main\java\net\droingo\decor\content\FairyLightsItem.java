package net.droingo.decor.content;

import net.droingo.decor.registry.DecorBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public final class FairyLightsItem extends Item {
    public static final String ROOT = "DroingosDecorFairyLights";
    public static final String HAS_FIRST = "HasFirst";
    public static final String DIMENSION = "Dimension";
    public static final String ANCHOR_POS = "AnchorPos";
    public static final String POINT_X = "PointX";
    public static final String POINT_Y = "PointY";
    public static final String POINT_Z = "PointZ";

    private static final double MAX_DISTANCE = 16.0D;

    public FairyLightsItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Player player = context.getPlayer();
        if (player == null) {
            return InteractionResult.PASS;
        }

        Level level = context.getLevel();
        CompoundTag root = player.getPersistentData();
        CompoundTag data = root.getCompound(ROOT);

        Vec3 clickedPoint = offsetFromSurface(
                context.getClickLocation(),
                context.getClickedFace()
        );

        if (!data.getBoolean(HAS_FIRST)) {
            BlockPos anchorBlockPos = placementBlockPos(
                    context.getClickedPos(),
                    context.getClickedFace()
            );

            data.putBoolean(HAS_FIRST, true);
            data.putString(
                    DIMENSION,
                    level.dimension().location().toString()
            );
            data.putLong(ANCHOR_POS, anchorBlockPos.asLong());
            data.putDouble(POINT_X, clickedPoint.x);
            data.putDouble(POINT_Y, clickedPoint.y);
            data.putDouble(POINT_Z, clickedPoint.z);
            root.put(ROOT, data);

            if (!level.isClientSide) {
                player.displayClientMessage(
                        Component.literal(
                                "Fairy lights: first point selected. "
                                        + "Right-click the second point."
                        ),
                        true
                );
            }

            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        if (!data.getString(DIMENSION).equals(
                level.dimension().location().toString()
        )) {
            clear(player);
            if (!level.isClientSide) {
                player.displayClientMessage(
                        Component.literal(
                                "Fairy lights selection cleared: "
                                        + "both points must be in the same dimension."
                        ),
                        true
                );
            }
            return InteractionResult.FAIL;
        }

        Vec3 firstPoint = firstPoint(data);
        double distance = firstPoint.distanceTo(clickedPoint);

        if (distance < 0.5D || distance > MAX_DISTANCE) {
            if (!level.isClientSide) {
                player.displayClientMessage(
                        Component.literal(
                                distance > MAX_DISTANCE
                                        ? "Fairy lights are limited to 16 blocks."
                                        : "The two points are too close together."
                        ),
                        true
                );
            }
            return InteractionResult.FAIL;
        }

        BlockPos anchorPos = BlockPos.of(data.getLong(ANCHOR_POS));
        boolean existingAnchor =
                level.getBlockState(anchorPos).is(DecorBlocks.FAIRY_LIGHTS_TEST);

        if (!existingAnchor
                && !level.getBlockState(anchorPos).canBeReplaced()) {
            clear(player);
            if (!level.isClientSide) {
                player.displayClientMessage(
                        Component.literal(
                                "The first attachment point is now obstructed."
                        ),
                        true
                );
            }
            return InteractionResult.FAIL;
        }

        if (!level.isClientSide) {
            if (!existingAnchor) {
                level.setBlock(
                        anchorPos,
                        DecorBlocks.FAIRY_LIGHTS_TEST
                                .get()
                                .defaultBlockState(),
                        3
                );
            }

            if (level.getBlockEntity(anchorPos)
                    instanceof FairyLightsTestBlockEntity lights) {
                lights.addConnection(
                        firstPoint,
                        clickedPoint,
                        context.isSecondaryUseActive(),
                        colorFromStack(context.getItemInHand())
                );
            }

            if (!player.getAbilities().instabuild) {
                context.getItemInHand().shrink(1);
            }

            player.displayClientMessage(
                    Component.literal(
                            existingAnchor
                                    ? "Another fairy-light string was added "
                                            + "to this mounting point."
                                    : "Fairy lights placed."
                    ),
                    true
            );
        }

        clear(player);
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    public static boolean hasFirstPoint(Player player) {
        return player.getPersistentData()
                .getCompound(ROOT)
                .getBoolean(HAS_FIRST);
    }

    public static Vec3 selectedPoint(Player player) {
        return firstPoint(
                player.getPersistentData().getCompound(ROOT)
        );
    }

    private static Vec3 firstPoint(CompoundTag data) {
        return new Vec3(
                data.getDouble(POINT_X),
                data.getDouble(POINT_Y),
                data.getDouble(POINT_Z)
        );
    }

    private static DyeColor colorFromStack(ItemStack stack) {
        return stack.getItem() instanceof DyeItem dye
                ? dye.getDyeColor()
                : DyeColor.WHITE;
    }

    private static BlockPos placementBlockPos(
            BlockPos clickedPos,
            Direction face
    ) {
        return clickedPos.relative(face);
    }

    public static Vec3 offsetFromSurface(
            Vec3 hit,
            Direction face
    ) {
        Vec3 normal = Vec3.atLowerCornerOf(face.getNormal());
        return hit.add(normal.scale(0.015625D));
    }

    private static void clear(Player player) {
        player.getPersistentData().remove(ROOT);
    }
}